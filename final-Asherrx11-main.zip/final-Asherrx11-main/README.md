# Final Project

## Objective
You will design and develop a web application that will allow users to request different Astronomy Pictures of the Day by date using NASA APOD API. Users will also be able to save pictures as favourites.
